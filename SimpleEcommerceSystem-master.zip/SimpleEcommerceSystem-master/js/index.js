$(".menu-button").click(function () {
 
    $('.box').toggleClass('closed');
    $('.inner-box').toggleClass('inner-box-closed');
     $('.box').addClass('indx');
    });

$(".menu-item").click(function () {
 
    $('.box').toggleClass('closed');
    $('.inner-box').toggleClass('inner-box-closed');
    
    });
